<?php

Route::resource('stores', 'SiteController');