@extends('Common::layout')

@section('page')
    <h3>stores Single</h3>
@stop