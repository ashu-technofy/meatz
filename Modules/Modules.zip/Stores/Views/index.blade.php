@extends('Common::layout')

@section('page')
    <h3>stores Index</h3>
@stop