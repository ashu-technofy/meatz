<?php

namespace Modules\Stores\Models;

use Modules\Common\Models\HelperModel;

class StoreSubcategory extends HelperModel
{
    protected $table = "store_subcategories";


    // public function storeSubCategries()
    // {
    //     return $this->belongsTo(StoreCategory::class,'category_id');
    // }


}
