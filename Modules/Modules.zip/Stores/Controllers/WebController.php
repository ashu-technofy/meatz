<?php

namespace Modules\Stores\Controllers;

use App\Http\Controllers\Controller;

class WebController extends Controller
{
}
