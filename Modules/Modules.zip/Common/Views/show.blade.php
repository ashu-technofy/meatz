@extends('Common::layout')

@section('page')
    <h3>common Single</h3>
@stop