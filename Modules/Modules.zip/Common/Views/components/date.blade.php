<div class="form-group">
    <label for="exampleInputEmail1">{{ $mytitle }}</label>
    <input type="date" {{ $required }} name="{{ $name }}" value="{{ $value }}" class="form-control"
        placeholder="{{ $mytitle }}">
</div>