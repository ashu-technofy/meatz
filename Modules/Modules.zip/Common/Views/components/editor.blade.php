<div class="mb-3">
    <label>{{ $mytitle }}</label>
    <textarea class="textarea" name="{{ $name }}" placeholder="{{ $mytitle }}">{{ $value }}</textarea>
</div>