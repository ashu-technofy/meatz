<?php

Route::get('home', 'ApiController@home');
