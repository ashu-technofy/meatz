<?php

namespace Modules\Common\Controllers;

use App\Http\Controllers\Controller;

class SiteController extends Controller
{
}
